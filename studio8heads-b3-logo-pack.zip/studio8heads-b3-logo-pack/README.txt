STUDIO 8HEADS — B3 "TOTEM" LOGO PACK
=====================================

Colours
  Coral  #FF5A36
  Ink    #141414
  Cream  #F5F3EE
Fonts used (already converted to shapes in every file — you don't need to install them)
  Letters: Archivo Black · Wordmark: Space Grotesk Bold (both free Google Fonts)

FOLDERS
  svg/        Best for websites: sharp at any size, tiny files.
  png/        Same logos as images (normal + @2x for retina screens), transparent backgrounds.
  favicon/    Browser tab icon + phone home-screen icons.
  animation/  The animated logo: SVG (loops, smallest), MP4/WebM (video), GIF (social / chat).

WHICH FILE TO USE
  s8h-horizontal-logo.svg        Website header on a light background
  s8h-horizontal-logo-white.svg  Website header on a dark background
  s8h-totem-logo.svg             Tall logo for light backgrounds (hero, about page, footer)
  s8h-totem-logo-white.svg       Tall logo for dark backgrounds
  s8h-totem-mark(.svg / -coral)  The S8H pill alone, no wordmark
  s8h-totem-logo-square.svg      Logo on a coral square — social profile pictures, og:image
  s8h-horizontal-logo-card.svg   Logo on a coral card — banners, link previews
  s8h-sticker.svg / s8h-poster.svg  Merch and promo graphics
  s8h-icon.svg                   App icon (rounded square)

PASTE INTO YOUR SITE
-------------------
1) Favicon — copy the favicon/ files to your site's root folder, then put this in <head>:

  <link rel="icon" href="/favicon.ico" sizes="any">
  <link rel="icon" href="/favicon.svg" type="image/svg+xml">
  <link rel="apple-touch-icon" href="/apple-touch-icon.png">

2) Header logo:

  <a href="/" aria-label="Studio 8Heads home">
    <img src="/s8h-horizontal-logo.svg" alt="Studio 8Heads" height="48">
  </a>

3) Animated logo (loops on its own; stops automatically for visitors who turn off motion):

  <img src="/s8h-totem-animated.svg" alt="Studio 8Heads" width="380" height="380">

   Or as a video:

  <video autoplay muted loop playsinline width="380" poster="/s8h-totem-logo-square.png">
    <source src="/s8h-totem-animated.webm" type="video/webm">
    <source src="/s8h-totem-animated.mp4" type="video/mp4">
  </video>
